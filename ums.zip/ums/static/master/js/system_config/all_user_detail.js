function postMethod(data, url, suc_msg, loading_icon_text="Saving Details..."){
    loadingicon(loading_icon_text)
    $.ajax({
        url:url,
        type:"POST",
        data:JSON.stringify(data),
        contentType:"application/json",
        dataType:"json",
        headers:{
            'X-CSRFToken':  $('input[name="csrfmiddlewaretoken"]').val()
        },
        success:function(status){
            Swal.close()
            reloadPage(100);
            popUp(suc_msg, "success")
        },
        error:function(error){
            Swal.close()
            return popUp(error.responseJSON, "error");
        }
    })
}

function createMenuTable(table_name, table_data, column_data, display_length){
    var buttonCommon = {
        exportOptions: {
            format: {
                body: function ( data, row, column, node ) {
                    if(column == 4){
                        console.log(data)
                        data = data.split("<tbody>");
                        data.splice(0, 1);
                        data = data[0].split("</tbody>");
                        data.splice(data.length-1, 1);
                        return data[0].replace(/<\/td><\/tr>/g, " ").replace(/<tr><td>/g, " ");
                    }else if(column == 6){
                        return data.includes("Active")?"Active":"Close";
                    }else if(column == 7){
                        return "";
                    }else{
                        return data;
                    }
                }
            }
        }
    };

    $('#'+table_name).DataTable( {
        data:table_data,
        columns: column_data,
        dom: 'Bfrtip',
        iDisplayLength:display_length,
        buttons: [
            $.extend( true, {}, buttonCommon, {
                extend: 'copyHtml5'
            } ),
            $.extend( true, {}, buttonCommon, {
                extend: 'excelHtml5'
            } ),
        ]
    } );
}

$(document).ready(function () {
    createMenuTable("user_table", user_table_data.table_data, user_table_data.column_data, 20);
});

function showRoleBaseEntity(sel_role){
    role_based_entity_str = "";
    if(sel_role == "teacher"){
        role_based_entity_str += "<div class='col-md-6'>\
                                <h6>Department <medium style='color:red;'>*</medium></h6>\
                                <select id='user_dept' onchange='setSection(this.value)' multiple='multiple' class='form-control'>"+dept_option_str+"</select>\
                                </div><div class='col-md-6' id='user_sec_entity'></div>";
        document.getElementById("role_based_entity").innerHTML = role_based_entity_str;
        $('#user_dept').multiselect({
            enableCaseInsensitiveFiltering: true,
            nonSelectedText: 'No Role Selected',
            includeSelectAllOption: true,
            buttonClass:'custom-select',
            maxHeight:300
        });
    }else if(sel_role == "student"){
        role_based_entity_str += "<div class='col-md-6'>\
                                <h6>Department <medium style='color:red;'>*</medium></h6>\
                                <select id='user_dept' onchange='setSection(this.value)' class='form-control'><option value='' selected disabled>Select Department</option>"+dept_option_str+"</select>\
                                </div><div class='col-md-6' id='user_sec_entity'></div>";
        document.getElementById("role_based_entity").innerHTML = role_based_entity_str;
    }
}

function setSection(sel_dept){
    document.getElementById("user_sec_entity").innerHTML = "";
    sel_role = document.getElementById("role").value;
    user_sec_entity_str = "";
    if(Object.keys(dept_sec_list[sel_dept]['section']).length){
        user_sec_entity_str = "<h6>Section <medium style='color:red;'>*</medium></h6>"
        if(sel_role == "teacher"){
            user_sec_entity_str += "<select id='user_sec' multiple='multiple' class='form-control'>";
            sel_dep = $("select#user_dept").val();
            for(sd in sel_dep){
                for(s in dept_sec_list[parseInt(sel_dep[sd])]['section']){
                    user_sec_entity_str += "<option value='"+s+"'>"+dept_sec_list[parseInt(sel_dep[sd])]['section'][s]+" ("+dept_sec_list[sel_dep[sd]]['dept_name']+")</option>";
                }
            }
        }
        else if(sel_role == "student"){
            user_sec_entity_str += "<select id='user_sec' class='form-control'><option value='' selected disabled>Select Section</option>";
            for(s in dept_sec_list[sel_dept]['section']){
                user_sec_entity_str += "<option value='"+s+"'>"+dept_sec_list[sel_dept]['section'][s]+" ("+dept_sec_list[sel_dept]['dept_name']+")</option>";
            }
        }
        user_sec_entity_str += "</select>";
    }
    document.getElementById("user_sec_entity").innerHTML = user_sec_entity_str;
    if(sel_role == "teacher"){
        $('#user_sec').multiselect({
            enableCaseInsensitiveFiltering: true,
            nonSelectedText: 'No Role Selected',
            includeSelectAllOption: true,
            buttonClass:'custom-select',
            maxHeight:200
        });
    }
}

function addUserModal(){
    ['#first_name', '#last_name', '#email', '#mobile_no', '#role'].map((ids)=>{$(ids).val("")});
    ['user_modal_header', 'role_based_entity', 'user_modal_btn'].map((ids)=>{document.getElementById(ids).innerHTML="";});
    // $("#access_label").multiselect("deselectAll");
    document.getElementById("user_modal_header").innerHTML = "Create New User";
    document.getElementById("user_modal_btn").innerHTML = "<button class='btn btn-outline-success' onclick='createUser()'>Add</button>";
    close_Or_Open_Modal("#user_modal", "show");
}

function createUser(){
    new_user_data = {'department':[], 'section':[]}
    field_ids = {'first_name':"First Name", 'last_name':"Last Name", 'email':"Email", 'mobile_no':"Mobile Number", 'role':"Role"};
    for(ids in field_ids){
        new_user_data[ids] = $('#'+ids).val();
        if(!new_user_data[ids] || new_user_data[ids] == "" || new_user_data[ids] == " "){
            new_user_data = {};
            return popUp("Please Provide "+field_ids[ids], "error");
        }
    }
    if(new_user_data['role'] == "teacher"){
        sel_user_dept =  $("select#user_dept").val();
        if(!sel_user_dept){
            return popUp("Please Select at least One Department", "error");
        }
        sel_user_sec =  $("select#user_sec").val();
        if(!sel_user_sec){
            return popUp("Please Select at least One Section", "error");
        }
    }else if(new_user_data['role'] == "student"){
        sel_user_dept = $("#user_dept").val();
        if(!sel_user_dept || sel_user_dept == " " || sel_user_dept == "")
            return popUp("Please Select Department", "error")
        sel_user_sec = $("#user_sec").val();
        if(!sel_user_sec || sel_user_sec == " " || sel_user_sec == "")
            return popUp("Please Select Section", "error")
        sel_user_dept = [sel_user_dept];
        sel_user_sec = [sel_user_sec];
    }
    new_user_data['department'] = sel_user_dept;
    new_user_data['section'] = sel_user_sec;
    postMethod(new_user_data, '/create_user/', 'User Created Successfully');

}

function changeUserStatus(id){
    text = "Change Status From Active To Close";
    succ_msg = "Status Changed to Close";
    if(document.getElementById(id).checked){
        text = "Change Status From Close To Active";
        succ_msg = "Status Changed to Active";
    }
    Swal.fire({
        title: 'Are you sure?',
        text: text,
        icon: 'warning',
        showCancelButton: true,
        allowOutsideClick: false,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, Proceed!'
      }).then((result) => {
        if (result.value) {
            loadingicon("Changing Status...")
            $.ajax({
                url:"/create_user/",
                type:"PUT",
                data:JSON.stringify({'id':id, 'status':document.getElementById(id).checked}),
                contentType:"application/json",
                dataType:"json",
                headers:{
                    'X-CSRFToken':  $('input[name="csrfmiddlewaretoken"]').val()
                },
                success:function(status){
                    Swal.close()
                    reloadPage(100);
                    popUp(succ_msg, "success")
                },
                error:function(error){
                    Swal.close()
                    return popUp(error.responseJSON, "error");
                }
            })
        }else{
            if(document.getElementById(id).checked){
                document.getElementById(id).checked = false;
            }else{
                document.getElementById(id).checked = true;
            }
        }
    });
}
