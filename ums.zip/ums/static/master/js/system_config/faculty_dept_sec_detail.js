function postMethod(data, url, suc_msg, loading_icon_text="Saving Details..."){
    loadingicon(loading_icon_text)
    $.ajax({
        url:url,
        type:"POST",
        data:JSON.stringify(data),
        contentType:"application/json",
        dataType:"json",
        headers:{
            'X-CSRFToken':  $('input[name="csrfmiddlewaretoken"]').val()
        },
        success:function(status){
            Swal.close()
            reloadPage(100);
            popUp(suc_msg, "success")
        },
        error:function(error){
            Swal.close()
            return popUp(error.responseJSON, "error");
        }
    })
}

function createMenuTable(table_name, table_data, column_data, display_length){
    var buttonCommon = {
        exportOptions: {
            format: {
                body: function ( data, row, column, node ) {
                    if(column == 4){
                        console.log(data)
                        data = data.split("<tbody>");
                        data.splice(0, 1);
                        data = data[0].split("</tbody>");
                        data.splice(data.length-1, 1);
                        return data[0].replace(/<\/td><\/tr>/g, " ").replace(/<tr><td>/g, " ");
                    }else if(column == 6){
                        return data.includes("Active")?"Active":"Close";
                    }else if(column == 7){
                        return "";
                    }else{
                        return data;
                    }
                }
            }
        }
    };

    $('#'+table_name).DataTable( {
        data:table_data,
        columns: column_data,
        dom: 'Bfrtip',
        iDisplayLength:display_length,
        buttons: [
            $.extend( true, {}, buttonCommon, {
                extend: 'copyHtml5'
            } ),
            $.extend( true, {}, buttonCommon, {
                extend: 'excelHtml5'
            } ),
        ]
    } );
}

function createStudentTable(table_name, table_data, display_length){
    var buttonCommon = {
        exportOptions: {
            format: {
                body: function ( data, row, column, node ) {
                    return data;
                }
            }
        }
    };

    $('#'+table_name).DataTable( {
        data:table_data,
        columns:[
            {data:'username'},
            {data:'name'},
            {data:'email'},
            {data:'mobile'},
        ],
        dom: 'Bfrtip',
        iDisplayLength:display_length,
        buttons: [
            $.extend( true, {}, buttonCommon, {
                extend: 'copyHtml5'
            } ),
            $.extend( true, {}, buttonCommon, {
                extend: 'excelHtml5'
            } ),
        ]
    } );
}

$(document).ready(function () {
    createMenuTable("dept_sec_table", dept_sec_table_data.table_data, dept_sec_table_data.column_data, 20);
    createStudentTable("student_table", [], 20);
});

function showStudentDetail(secid){
    loadingicon("Fetching Student Details...")
    $.ajax({
        url:"/get_student_detail/"+secid+"/",
        type:"GET",
        headers:{
            'X-CSRFToken':  $('input[name="csrfmiddlewaretoken"]').val()
        },
        success:function(data){
            Swal.close()
            dt = $("#student_table").DataTable();
            dt.destroy();
            createStudentTable("student_table", data, 20);
            document.getElementById("stud_table_div").style = "display:block";
        },
        error:function(error){
            Swal.close()
            return popUp("Unable to Fetch Student Details", "error");
        }
    })
}

function setSection(sel_dept){
    sec_option_str = "<option value='' selected disabled>Select Section</option>";
    for(s in dept_sec_list[sel_dept]['section']){
        sec_option_str += "<option value='"+s+"'>"+dept_sec_list[sel_dept]['section'][s]+" ("+dept_sec_list[sel_dept]['dept_name']+")</option>";
    }
    document.getElementById("user_sec").innerHTML = sec_option_str;
}

function addUserModal(){
    ['#first_name', '#last_name', '#email', '#mobile_no', '#user_dept', '#user_sec'].map((ids)=>{$(ids).val("")});
    close_Or_Open_Modal("#user_modal", "show");
}

function createUser(){
    new_user_data = {}
    field_ids = {'first_name':"First Name", 'last_name':"Last Name", 'email':"Email", 'mobile_no':"Mobile Number"};
    for(ids in field_ids){
        new_user_data[ids] = $('#'+ids).val();
        if(!new_user_data[ids] || new_user_data[ids] == "" || new_user_data[ids] == " "){
            new_user_data = {};
            return popUp("Please Provide "+field_ids[ids], "error");
        }
    }
    sel_user_dept = $("#user_dept").val();
    if(!sel_user_dept || sel_user_dept == " " || sel_user_dept == "")
        return popUp("Please Select Department", "error")
    sel_user_sec = $("#user_sec").val();
    if(!sel_user_sec || sel_user_sec == " " || sel_user_sec == "")
        return popUp("Please Select Section", "error")
    new_user_data['department'] = [sel_user_dept];
    new_user_data['section'] = [sel_user_sec];
    new_user_data['role'] = "student";
    postMethod(new_user_data, '/create_user/', 'User Created Successfully');

}

