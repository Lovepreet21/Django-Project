from django.db import models
from django.contrib.auth.models import User, Group
from django.utils import timezone
from django.conf import settings
import pytz

class Menu(models.Model):
    menu_name = models.CharField(max_length=200,blank=True,null=True)
    submenu = models.BooleanField(default = False)
    submenu_name = models.CharField(max_length=200,blank=True,null=True)
    link = models.CharField(max_length=300,blank=True,null=True)
    icon = models.CharField(max_length=100,blank=True,null=True)
    access_label = models.CharField(max_length=200,blank=True,null=True)
    priority = models.IntegerField(blank = True, null = True)
    sm_priority = models.IntegerField(blank = True, null = True)
    def __str__(self):
        return self.menu_name

class Faculty(models.Model):
    user = models.ForeignKey(User, on_delete = models.CASCADE)
    mobile_no = models.CharField(max_length=300)
    family_detail = models.TextField(blank = True, null = True)
    created_by = models.ForeignKey(User, related_name="facultyCreator", null = True, on_delete = models.SET_NULL)
    def __str__(self, request):
        return self.user.username

class Student(models.Model):
    user = models.ForeignKey(User, on_delete = models.CASCADE)
    father_name = models.CharField(max_length=300)
    age = models.CharField(max_length=300)
    mobile_no = models.CharField(max_length=300)
    present_address = models.TextField(blank = True, null = True)
    permanent_address = models.TextField(blank = True, null = True)
    emergency_detail = models.TextField(blank = True, null = True)
    created_by = models.ForeignKey(User, related_name="studentCreator", null = True, on_delete = models.SET_NULL)
    def __str__(self):
        return self.user.username

class FacultyStudentMapping(models.Model):
    faculty = models.ForeignKey(Faculty, on_delete=models.CASCADE)
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    created_on = models.DateTimeField(auto_now_add = True)
    created_by = models.ForeignKey(User, null = True, on_delete=models.SET_NULL)
    def __str__(self):
        return  self.student.user.id+" ("+self.faculty.user.username+")"

class Department(models.Model):
    name = models.CharField(max_length=300)
    def __str__(self):
        return self.name

class Section(models.Model):
    name = models.CharField(max_length=300)
    dept = models.ForeignKey(Department, on_delete=models.CASCADE)
    def __str__(self):
        return self.name + " (" + self.dept.name + ")"

class FacultySectionMapping(models.Model):
    faculty = models.ForeignKey(Faculty, on_delete=models.CASCADE)
    section = models.ForeignKey(Section, on_delete=models.CASCADE)
    def __str__(self):
        return self.faculty.user.username + " ("+ self.section.name + ")"

class StudentSectionMapping(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    section = models.ForeignKey(Section, on_delete=models.CASCADE)
    def __str__(self):
        return self.student.user.username + " ("+ self.section.name + ")"

