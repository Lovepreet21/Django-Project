from django.contrib import admin
from django.apps import apps

userapp = apps.get_app_config('master').get_models()
for model in userapp:
    admin.site.register(model)
