from django.shortcuts import render
from django.shortcuts import render, redirect
from django.conf import settings
from django.views import View
from django.apps import apps
from django.contrib import admin, messages
from django.contrib.auth.models import User
from django.http import HttpResponse, JsonResponse, QueryDict
from rest_framework.permissions import AllowAny, IsAuthenticated
from django.core.files.storage import default_storage
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from rest_framework import status, views, generics, viewsets
from django.views.decorators.csrf import csrf_exempt
from rest_framework.response import Response 
from django.db.models.query_utils import Q
from django.contrib.auth.forms import PasswordResetForm
from django.utils.http import urlsafe_base64_encode
from django.contrib.auth.tokens import default_token_generator
from django.utils.encoding import force_bytes
import pandas as pd
import random, ast, datetime, json, socket, uuid, pytz, sys, re, logging
from datetime import date, timezone, timedelta
from .models import *
from .serializers import *

# This function will provide error/exception information
def printError(e, formname):
    exc_type, exc_obj, exc_tb = sys.exc_info()
    print("error line => ", exc_tb.tb_lineno)
    print(e, formname)

# This function will provide menu detils in all pages alongwith user details
def get_menu_for_user(user_obj):
    username, user_name, profile_pic, home_img, footer_img = user_obj.username, user_obj.get_full_name(), "profile_pic/user.jpg", "/static/media/ums-logo.png", "/static/media/university-hat.png"
    user_role = []
    if user_obj.is_superuser:
        user_role.append("sadmin")
    user_group_obj = user_obj.groups.values_list('name',flat = True)
    for r in user_group_obj:
        if r.capitalize() not in user_role:
            user_role.append(r.capitalize())
    user_group_obj = set(user_group_obj)
    menuObj = Menu.objects.all()
    menu_list = []
    for m in menuObj:
        access_label_set = set()
        if m.access_label:
            access_label_set = set(m.access_label.split("+"))
        if user_group_obj.intersection(access_label_set) or user_obj.is_superuser:
            menu_exist = False
            for ml in menu_list:
                if m.menu_name == ml['menu_name']:
                    menu_exist = True
                    ml['submenu'].append({'submenu_name':m.submenu_name, 'link':m.link, 'priority':m.sm_priority})
            if not menu_exist:
                menu_data = {}
                if m.menu_name not in menu_data:
                    menu_data['menu_name'] = m.menu_name
                    menu_data['icon'] = m.icon
                    menu_data['priority'] = m.priority
                    menu_data['submenu'] = []
                if m.submenu:
                    menu_data['submenu'].append({'submenu_name':m.submenu_name, 'link':m.link, 'priority':m.sm_priority})
                elif 'link' not in menu_data:
                    menu_data['link'] = m.link
                menu_list.append(menu_data)
    sorted_menu_list = sorted(menu_list, key = lambda k : k['priority'])
    for sml in sorted_menu_list:
        if sml['submenu']:
            submenu_data = sml.pop('submenu')
            sml['submenu'] = sorted(submenu_data, key = lambda k: k['priority'])
    
    return {'header':'UMS', 'username':username, 'user_name':user_name, 'profile_pic':profile_pic, 'footer_img':footer_img, 'home_img':home_img, 'menu_list':sorted_menu_list}

# This function allows the asscess of module based upon the user role
def allowAccessToMenu(requested_api_url, userObj):
    allow_access = False
    try:
        user_group = set(userObj.groups.values_list('name',flat = True))
        access_grp = set(Menu.objects.get(link = requested_api_url).access_label.split('+'))
        if user_group.intersection(access_grp): 
            allow_access = True
    except Exception as e:
        printError(e, " allowAccessMenu ")
    return allow_access

class LoginView(views.APIView):
    permission_classes = (AllowAny, )
    def get(self, request):
        context = {'logo':'/static/media/ums-logo.png'}
        if request.user.is_authenticated:
            return redirect('/')
        else:
            return render(request, 'login.html', context)

    def post(self, request):
        username, password = request.POST.get('userid', ''), request.POST.get('password', '')
        try:
            user = User.objects.get(username=username)
            if not user.is_active:
                messages.error(request,'User Account is Not Active')
                return redirect('/')
            user = authenticate(username=user.username,password=password)
            if user is not None:
                login(request, user)
                return redirect('/')
            else:
                messages.error(request,'Email ID or Password Not Correct')
                return redirect('/')
        except Exception as e:
            printError(e, "LoginView in post")
            messages.error(request,'User Does Not Exist')
            return redirect('/')

class PasswordResetRequest(views.APIView):
    def get(self, request):
        password_reset_form = PasswordResetForm()
        return render(request=request, template_name="password/password_reset.html", context={"password_reset_form":password_reset_form})

    def post(self, request):
        try:
            password_reset_form = PasswordResetForm(request.POST)
            if password_reset_form.is_valid():
                data = password_reset_form.cleaned_data['email']
                associated_users = User.objects.filter(Q(email=data))
                if associated_users.exists():
                    for user in associated_users:
                        protocol = request.META['SERVER_PROTOCOL'].split('/')[0].lower()+'://'
                        subject = "Password Reset Requested"
                        pass_reset_link = protocol+request.META['HTTP_HOST']+"/reset/"+urlsafe_base64_encode(force_bytes(user.pk))+"/"+default_token_generator.make_token(user)+"\\"
                        msg = "<p>Hello,</p><p>We received a request to reset the password for your account for this email address. \
                                To initiate the password reset process for your account, click the link below.</p>"+pass_reset_link+"\
                                <p>This link can only be used once. If you need to reset your password again, please visit "+protocol+request.META['HTTP_HOST']+" and request another reset.</p>\
                                <p>If you did not make this request, you can simply ignore this email.</p>"
                        try:
                            # sendEmail(subject,msg,user.email)
                            print("Mail is Sent link -> {0}".format(pass_reset_link))
                        except BadHeaderError:
                            return HttpResponse('Invalid header found.')
                        messages.success(request, 'Follow the link to reset the pssword <a href="{0}">Click Here</a>'.format(pass_reset_link))
                        return redirect ("/")
            messages.error(request, 'An invalid email has been entered.')
        except Exception as e:
            printError(e, "PasswordResetRequest in post")

class LogoutView(views.APIView):
    def get(self, request):
        logout(request)
        return redirect('/')

class HomePageView(views.APIView):
    # permission_classes = (IsAuthenticated, )
    # Adding this decorator will not allow the access of the API until user is not logged in
    @method_decorator(login_required(login_url = '/login/'))
    def get(self, request):
        # Calling get_menu_for_user() function for getting the required menu based upon the role that user has.
        context = get_menu_for_user(request.user)
        context['page_title'] = "University Management System"
        context['menus'] = [{'Home':'/'}]
        context['user'] = {'email':request.user.email, 'mobile_no':"", 'section_teacher':[]}
        usr_grp = list(request.user.groups.values_list('name', flat=True))
        if 'teacher' in usr_grp:
            context['user']['mobile_no'] = Faculty.objects.get(user_id=request.user.id).mobile_no
        elif 'student' in usr_grp:
            context['user']['mobile_no'] = Student.objects.get(user_id=request.user.id).mobile_no
            studObj = Student.objects.get(user_id = request.user.id)
            smObj = StudentSectionMapping.objects.get(student_id = studObj.id)
            context['user']['department_name'] = smObj.section.dept.name
            context['user']['section_name'] = smObj.section.name
            try:
                [context['user']['section_teacher'].append({'name':fsm.faculty.user.get_full_name(),
                                                            'email':fsm.faculty.user.email}) for fsm in FacultySectionMapping.objects.filter(section_id = smObj.id, section__dept_id = smObj.section.dept_id)]
            except Exception as e:
                printError(e, "")
                pass
        context['user']['grp'] = usr_grp
        return render(request, 'home.html', context)

class UserProfile(views.APIView):
    def get(self, request, uid):
        if not request.user.is_superuser:
            if not allowAccessToMenu('/user_profile/', request.user):
                return redirect('/')
        context = get_menu_for_user(request.user)
        menuObj = Menu.objects.get(link = "/user_profile/")
        context['page_title'] = menuObj.submenu_name if menuObj.submenu else menuObj.menu_name
        context['menus'] = []
        if menuObj.submenu:
            context['menus'].extend([{menuObj.menu_name:menuObj.link}, {menuObj.submenu_name:menuObj.link}])
        else:
            context['menus'].append({menuObj.menu_name:menuObj.link})

        return render(request, 'master/user_profile.html', context)

class AllUserDetails(views.APIView):
    def get(self, request):
        if not request.user.is_superuser:
            if not allowAccessToMenu('/all_user_details/', request.user):
                return redirect('/')
        context = get_menu_for_user(request.user)
        menuObj = Menu.objects.get(link = "/all_user_details/")
        context['page_title'] = menuObj.submenu_name if menuObj.submenu else menuObj.menu_name
        context['menus'] = []
        if menuObj.submenu:
            context['menus'].extend([{menuObj.menu_name:menuObj.link}, {menuObj.submenu_name:menuObj.link}])
        else:
            context['menus'].append({menuObj.menu_name:menuObj.link})
        context['group'] = [{'id':g.id, 'name':g.name.capitalize()} for g in Group.objects.all()]
        context['dept_sec_list'] = {}
        for d in Department.objects.all():
            if d.id not in context['dept_sec_list']:
                context['dept_sec_list'][d.id] = {'dept_name':d.name, 'section':{}}
            for s in Section.objects.filter(dept_id = d.id):
                context['dept_sec_list'][d.id]['section'][s.id] = s.name
        context['user_table_data'] = {'table_data':[], 'column_data':[]}
        context['user_table_data']['column_data'].extend([{'title':"Username", 'data':'username'},
                                                        {'title':"Name", 'data':'name'},
                                                        {'title':"Email ID", 'data':'email'},
                                                        {'title':"Mobile Number", 'data':'mobile_no'},
                                                        {'title':"Department & Section", 'data':'dept_sec'},
                                                        {'title':"Role", 'data':'access'},
                                                        {'title':"Date of Joining", 'data':'doj'},
                                                        {'title':"Status", 'data':'status'}])
        user_obj = User.objects.filter(is_superuser = False)
        for u in user_obj:
            mobile_no, dept_sec_str = "NA", "<table class='table table-sm table-hover'><tbody>"+("<tr><th>NA</th></tr>" if u.is_superuser else "")+""
            usr_grp = u.groups.values_list('name', flat=True)
            if 'teacher' in usr_grp:
                mobile_no = Faculty.objects.get(user_id=u.id).mobile_no
                for d in FacultySectionMapping.objects.filter(faculty_id = Faculty.objects.get(user_id=u.id).id):
                    dept_sec_str += "<tr><td>"+d.section.dept.name+"</td><td>"+d.section.name+"</td></tr>"
            elif 'student' in usr_grp:
                mobile_no = Student.objects.get(user_id=u.id).mobile_no
                for s in StudentSectionMapping.objects.filter(student_id = Student.objects.get(user_id=u.id).id):
                    dept_sec_str += "<tr><td>"+s.section.dept.name+"</td><td>"+s.section.name+"</td></tr>"
            access_str = "<table class='table table-sm table-hover'><tbody>"+("<tr><th>Super Admin</th></tr>" if u.is_superuser else "")+""
            for g in usr_grp:
                access_str+="<tr><th>"+g.capitalize()+"</th></tr>"
            if not usr_grp:
                access_str+="<tr><td>No Role Assigned</td></tr>"
            status_str = "<label class='switch'>\
                        <input type='checkbox' id='"+u.username+"_"+str(u.id)+"' onclick='changeUserStatus(this.id)' "+('checked' if u.is_active else "")+" />\
                        <div class='slider round'><span class='switchOn'>Active</span><span class='switchOff'>Close</span></div></label>"
            context['user_table_data']['table_data'].append({'username':u.username,
                                                            'name':u.get_full_name(),
                                                            'email':u.email,
                                                            'mobile_no':mobile_no,
                                                            'dept_sec':dept_sec_str+"</tbody></table>",
                                                            'access':access_str+"</tbody></table>",
                                                            'doj':u.date_joined.strftime("%d %b %Y %H:%M:%S"),
                                                            'status':status_str})
        return render(request, 'master/system_config/all_user_details.html', context)

class CreateUser(views.APIView):
    def post(self, request):
        try:
            data = request.data
            d = {}
            for k in ['department', 'section', 'mobile_no', 'role']:
                d[k] = data.pop(k)
            if d['role'] == "teacher":
                try:
                    factObj = Faculty.objects.get(mobile_no = d['mobile_no'])
                    return Response("Mobile Number Already Exist", status=400)
                except:
                    pass
            if d['role'] == "student":
                try:
                    factObj = Student.objects.get(mobile_no = d['mobile_no'])
                    return Response("Mobile Number Already Exist", status=400)
                except:
                    pass
            try:
                userObj = User.objects.get(email = data['email'])
                return Response("Email ID Already Exist", status=400)
            except:
                pass
            date_joined = datetime.datetime.now()
            user_id = [u.id for u in User.objects.all()]
            user_id.sort(reverse=True)
            data['username'] = date_joined.strftime("%Y%m%d") + (str(user_id[0]+1 if user_id else 1).zfill(3))
            userObj = User.objects.create(**data)
            grpObj = Group.objects.get(name = d['role'])
            userObj.groups.add(grpObj)
            userObj.set_password("pass")
            userObj.save()
            if d['role'] == "teacher":
                factObj = Faculty.objects.create(user_id = userObj.id, mobile_no = d['mobile_no'], created_by_id = request.user.id)
                for s in d['section']:
                    allowed=True
                    try:
                        fsmObj = FacultySectionMapping.objects.get(faculty_id = factObj.id, section_id = int(s))
                        allowed=False
                    except:
                        pass
                    if allowed:
                        FacultySectionMapping.objects.create(faculty_id = factObj.id, section_id = int(s))
            elif d['role'] == "student":
                studObj = Student.objects.create(user_id = userObj.id, mobile_no = d['mobile_no'], created_by_id = request.user.id)
                for s in d['section']:
                    allowed=True
                    try:
                        ssmObj = StudentSectionMapping.objects.get(student_id = studObj.id, section_id = int(s))
                        allowed = False
                    except:
                        pass
                    if allowed:
                        StudentSectionMapping.objects.create(student_id = studObj.id, section_id = int(s))
            return Response("success")
        except Exception as e:
            printError(e, "CreateUser in post")
        return Response("Error Occurred", status=400)
    
    def put(self, request):
        try:
            userObj = User.objects.get(id=request.data['id'].split('_')[-1])
            userObj.is_active = request.data['status']
            userObj.save()
            return Response("success")
        except Exception as e:
            printError(e, "CreateUser in put")
        return Response("User Does Not Exist", status=400)

# class GetUserData(ListCreateAPIView):
#     # queryset = Departments.objects.all()
#     # serializer_class = DepartmentsSerializer

class GetUserData(views.APIView):
    def get(self, request, uid):
        usr_data = {'mobile_no':""}
        try:
            userObj = User.objects.get(id = uid)
            usr_data = UserSerializer(userObj).data
            usr_data['access'] = u.groups.values_list('name', flat=True)
            if len(usr_data['access'])>1:
                return Response("Multiple Role Assigned. Please Assign Only One Role.", status=400)
            if 'teacher' in usr_data['access']:
                try:
                    usr_data['mobile_no'] = Faculty.objects.get(user_id = userObj.id).mobile_no
                except:
                    pass
            elif 'student' in usr_data['access']:
                try:
                    usr_data['mobile_no'] = Student.objects.get(user_id = userObj.id).mobile_no
                except:
                    pass
            print(usr_data)
        except:
            pass
        return Response(usr_data)

class FacultyDeptSecDetail(views.APIView):
    def get(self, request):
        if not request.user.is_superuser:
            if not allowAccessToMenu('/faculty_dept_sec_detail/', request.user):
                return redirect('/')
        context = get_menu_for_user(request.user)
        menuObj = Menu.objects.get(link = "/faculty_dept_sec_detail/")
        context['page_title'] = menuObj.submenu_name if menuObj.submenu else menuObj.menu_name
        context['menus'] = []
        if menuObj.submenu:
            context['menus'].extend([{menuObj.menu_name:menuObj.link}, {menuObj.submenu_name:menuObj.link}])
        else:
            context['menus'].append({menuObj.menu_name:menuObj.link})
        context['group'] = [{'id':g.id, 'name':g.name.capitalize()} for g in Group.objects.all()]
        context['dept_sec_list'] = {}
        for d in Department.objects.all():
            if d.id not in context['dept_sec_list']:
                context['dept_sec_list'][d.id] = {'dept_name':d.name, 'section':{}}
            for s in Section.objects.filter(dept_id = d.id):
                context['dept_sec_list'][d.id]['section'][s.id] = s.name
        context['dept_sec_table_data'] = {'table_data':[], 'column_data':[]}
        context['dept_sec_table_data']['column_data'].extend([{'title':"Department", 'data':'department'},
                                                            {'title':"Section", 'data':'section'}])
        if request.user.is_superuser:
            context['dept_sec_table_data']['column_data'].insert(0, {'title':"Faculty ID", 'data':'fid'})
            context['dept_sec_table_data']['column_data'].insert(1, {'title':"Faculty Name", 'data':'fname'})
            for u in Faculty.objects.all():
                dept_sec_map = {}
                fsmObj = FacultySectionMapping.objects.filter(faculty_id = u.id)
                for fsm in fsmObj:
                    if fsm.section.dept.id not in dept_sec_map:
                        dept_sec_map[fsm.section.dept.id] = {"dept_name":fsm.section.dept.name, 'section':{}}
                    if fsm.section.id not in dept_sec_map[fsm.section.dept.id]['section']:
                        dept_sec_map[fsm.section.dept.id]['section'][fsm.section.id] = {'sec_name':fsm.section.name, 'stud_count':len(StudentSectionMapping.objects.filter(section_id=fsm.section.id))}
                dept_str, sec_str = "<table class='table table-sm table-hover'><tbody>", "<table class='table table-sm table-hover'><tbody>"
                for dsm in dept_sec_map:
                    dept_str += "<tr><td>"+dept_sec_map[dsm]['dept_name']+"</td></tr>"
                    for s in dept_sec_map[dsm]['section']:
                        sec_str += "<tr><td>"+dept_sec_map[dsm]['section'][s]['sec_name']+"</td>\
                                    <td>"+str(dept_sec_map[dsm]['section'][s]['stud_count'])+"</td>\
                                    <td><span onclick=\"showStudentDetail('"+str(s)+"')\" class='badge badge-pill badge-warning m-1' style='cursor:pointer;'><i class='fas fa-eye'></i> View</span></tr></tr><tr>"
                context['dept_sec_table_data']['table_data'].append({'fid':u.user.username, 'fname':u.user.get_full_name(), 
                                                                    'department':dept_str, 'section':sec_str})
        else:
            dept_sec_map = {}
            fsmObj = FacultySectionMapping.objects.filter(faculty_id = Faculty.objects.get(user_id = request.user.id).id)
            for fsm in fsmObj:
                if fsm.section.dept.id not in dept_sec_map:
                    dept_sec_map[fsm.section.dept.id] = {"dept_name":fsm.section.dept.name, 'section':{}}
                if fsm.section.id not in dept_sec_map[fsm.section.dept.id]['section']:
                    dept_sec_map[fsm.section.dept.id]['section'][fsm.section.id] = {'sec_name':fsm.section.name, 'stud_count':len(StudentSectionMapping.objects.filter(section_id=fsm.section.id))}
            dept_str, sec_str = "<table class='table table-sm table-hover'><tbody>", "<table class='table table-sm table-hover'><tbody>"
            for dsm in dept_sec_map:
                dept_str += "<tr><td>"+dept_sec_map[dsm]['dept_name']+"</td></tr>"
                for s in dept_sec_map[dsm]['section']:
                    sec_str += "<tr><td>"+dept_sec_map[dsm]['section'][s]['sec_name']+"</td>\
                                <td>"+str(dept_sec_map[dsm]['section'][s]['stud_count'])+"</td>\
                                <td><span onclick=\"showStudentDetail('"+str(s)+"')\" class='badge badge-pill badge-warning m-1' style='cursor:pointer;'><i class='fas fa-eye'></i> View</span></td></tr>"
            context['dept_sec_table_data']['table_data'].append({'department':dept_str, 'section':sec_str+"</tbody></table>"})
        return render(request, 'master/system_config/faculty_dept_sec_detail.html', context)

class GetStudentDetail(views.APIView):
    def get(self, request, secid):
        stud_data = []
        try:
            print("secid => ", secid)
            for ssmObj in StudentSectionMapping.objects.filter(section_id = secid):
                stud_data.append({'username':ssmObj.student.user.username,
                                'name':ssmObj.student.user.get_full_name(),
                                'email':ssmObj.student.user.email,
                                'mobile':ssmObj.student.mobile_no})
        except Exception as e:
            printError(e, "GetStudentDetail in get")
        return Response(stud_data)
