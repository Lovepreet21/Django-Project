from django.contrib import admin
from django.urls import path, include
from django.views.generic import TemplateView
from .views import *

urlpatterns = [
    path('', HomePageView.as_view()),
    path('login/', LoginView.as_view()),
    path('logout/', LogoutView.as_view()),
    path('all_user_details/', AllUserDetails.as_view()),
    path('user_profile/<int:uid>/', UserProfile.as_view()),
    path('create_user/', CreateUser.as_view()),
    path('get_update_user_data/<int:uid>/', GetUserData.as_view()),
    path('faculty_dept_sec_detail/', FacultyDeptSecDetail.as_view()),
    path('get_student_detail/<int:secid>/', GetStudentDetail.as_view()),
]
